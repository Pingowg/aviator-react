# Aviator Simulador React

### Rodando localmente
```bash
npm install
npm run dev
```

### Deploy
- Netlify: build → pasta `dist`
- Vercel: detecta automaticamente Vite/React
